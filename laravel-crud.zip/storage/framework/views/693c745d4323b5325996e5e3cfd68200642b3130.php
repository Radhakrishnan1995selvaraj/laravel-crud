<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>
<body>
    <form action="<?php echo e(url('update/'.$user->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<label for="">Name: </label><input type="text" name="name" value="<?php echo e($user->name); ?>"><br><br>
<label for="">Phone: </label><input type="text" name="phone" value="<?php echo e($user->phone); ?>"><br><br>
<input type="submit" value="update user">


    </form>
</body>
</html><?php /**PATH C:\laravel\crud\resources\views/edit-view.blade.php ENDPATH**/ ?>