<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="store" method="POST">
@csrf
<label for="">Name: </label><input type="text" name="name"><br><br>
<label for="">Phone: </label><input type="text" name="phone"><br><br>
<input type="submit" value="submit">


    </form>
</body>
</html>