<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Crud;

class CrudController extends Controller
{
    public function create(){
    
        return view('home');

    }

    public function store(Request $request){
    
      $name=$request->input('name');
      $phone=$request->input('phone');

$crud= new Crud;
$crud->name=$name;
$crud->phone=$phone;


$crud->save();


return " <script>alert('data insert sucess'); window.location.href = '/list-view'; </script> " ;

    }

    public function list(){
    
        $crud=Crud::paginate(5);
        return view('list-view',['user'=>$crud]);

    }

    public function edit($id){
    
        $crud=Crud::find($id);
        return view('edit-view',['user'=>$crud]);

    }

    public function update(Request $request,$id){
    
        $crud=Crud::find($id);

        $crud->name=$request->input('name');
        $crud->phone=$request->input('phone');
        $crud->save();

        return " <script>alert('data Updated sucess'); window.location.href = '/list-view'; </script> " ;


    }
    public function delete($id){
    
        $crud=Crud::find($id);
        $crud->delete();
        
        return " <script>alert('data delete '); window.location.href = '/list-view'; </script> " ;


    }
}
